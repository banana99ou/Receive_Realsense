# rs-color Sample

## Overview
This sample demonstrates how to use C API to stream color data and prints some frame information such as frame number, timestamp, time of arrival, timestamp domain and a first 10 bytes of the frame data.
