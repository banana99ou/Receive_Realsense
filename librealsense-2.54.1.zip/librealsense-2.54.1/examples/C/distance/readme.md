# rs-distance Sample

## Overview
This sample demonstrates how to use C API to stream depth data and print the distance from the camera to the object in the center of the image.
